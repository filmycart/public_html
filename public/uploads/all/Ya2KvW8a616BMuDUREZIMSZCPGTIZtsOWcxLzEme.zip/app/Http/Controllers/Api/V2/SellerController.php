<?php
namespace App\Http\Controllers\Api\V2;

use App\Models\Order;
use Illuminate\Http\Request;
use App\Http\Resources\V2\PurchaseHistoryMiniCollection;
use App\Http\Resources\V2\PurchaseHistoryCollection;
use App\Http\Resources\V2\PurchaseHistoryItemsCollection;
use App\Models\OrderDetail;

class SellerController extends Controller {


    

}
?>